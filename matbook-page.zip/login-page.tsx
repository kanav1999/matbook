"use client"

import { useState } from "react"
import { CircleIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function LoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)
  const [staySignedIn, setStaySignedIn] = useState(false)
  const [receiveUpdates, setReceiveUpdates] = useState(false)

  return (
    <div className="flex h-screen w-full">
      {/* Left side - Background with text */}
      <div className="hidden md:flex md:w-1/2 flex-col p-12 bg-gradient-to-br from-[#2c3e50] to-[#849e4c] text-white">
        <div className="flex items-center gap-2 mb-16">
          <CircleIcon className="h-6 w-6 text-white" />
          <span className="font-semibold text-lg">nightBridge</span>
        </div>

        <div className="mt-16">
          <h1 className="text-3xl font-bold mb-3">Building the Future...</h1>
          <p className="text-sm opacity-80 max-w-xs">
            Join us as we build the next generation of financial infrastructure
          </p>
        </div>
      </div>

      {/* Right side - Login form */}
      <div className="w-full md:w-1/2 flex items-center justify-center bg-[#ffffff]">
        <div className="w-full max-w-md p-8">
          <h2 className="text-xl font-semibold mb-8">Log In to your Account</h2>

          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm text-[#4f4f4f]">
                Username
              </Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="border-[#e0e0e0] focus:border-[#76a9ff] focus:ring-[#76a9ff]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm text-[#4f4f4f]">
                Password
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="border-[#e0e0e0] focus:border-[#76a9ff] focus:ring-[#76a9ff]"
              />
            </div>

            <Button type="submit" className="w-full bg-[#ee3425] hover:bg-[#bf291e] text-white font-medium py-2">
              LOG IN
            </Button>

            <div className="space-y-3 pt-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked === true)}
                />
                <Label htmlFor="remember" className="text-xs text-[#4f4f4f]">
                  Remember Password
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="stay-signed-in"
                  checked={staySignedIn}
                  onCheckedChange={(checked) => setStaySignedIn(checked === true)}
                />
                <Label htmlFor="stay-signed-in" className="text-xs text-[#4f4f4f]">
                  Stay Signed In
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="updates"
                  checked={receiveUpdates}
                  onCheckedChange={(checked) => setReceiveUpdates(checked === true)}
                />
                <Label htmlFor="updates" className="text-xs text-[#4f4f4f]">
                  Receive Updates
                </Label>
              </div>
            </div>

            <div className="text-center">
              <a href="#" className="text-xs text-[#76a9ff] hover:underline">
                Forgot Password?
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

