import axios from "axios"

// Base URL for the Beeceptor API
const API_BASE_URL = "https://beeceptor.com/console/sample-api-for-testing"

// API service for making requests to the Beeceptor API
export const apiService = {
  // Get all users
  getUsers: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/users`)
      return response.data
    } catch (error) {
      console.error("Error fetching users:", error)
      throw error
    }
  },

  // Get a specific user by ID
  getUserById: async (id: string) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/users/${id}`)
      return response.data
    } catch (error) {
      console.error(`Error fetching user with ID ${id}:`, error)
      throw error
    }
  },

  // Create a new user
  createUser: async (userData: any) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/users`, userData)
      return response.data
    } catch (error) {
      console.error("Error creating user:", error)
      throw error
    }
  },

  // Update an existing user
  updateUser: async (id: string, userData: any) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/users/${id}`, userData)
      return response.data
    } catch (error) {
      console.error(`Error updating user with ID ${id}:`, error)
      throw error
    }
  },

  // Delete a user
  deleteUser: async (id: string) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/users/${id}`)
      return response.data
    } catch (error) {
      console.error(`Error deleting user with ID ${id}:`, error)
      throw error
    }
  },

  // Custom API call for workflow execution
  executeApiCall: async (url: string, method: string, body?: any, headers?: any) => {
    try {
      const config = {
        headers: headers || {
          "Content-Type": "application/json",
        },
      }

      let response

      switch (method.toUpperCase()) {
        case "GET":
          response = await axios.get(url, config)
          break
        case "POST":
          response = await axios.post(url, body, config)
          break
        case "PUT":
          response = await axios.put(url, body, config)
          break
        case "DELETE":
          response = await axios.delete(url, config)
          break
        default:
          throw new Error(`Unsupported method: ${method}`)
      }

      return response.data
    } catch (error) {
      console.error(`Error executing API call to ${url}:`, error)
      throw error
    }
  },

  // Send email (mock function)
  sendEmail: async (to: string, subject: string, body: string) => {
    try {
      // In a real application, this would call an email service API
      console.log(`Sending email to ${to} with subject "${subject}"`)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      return {
        success: true,
        message: `Email sent to ${to} successfully`,
        details: {
          to,
          subject,
          body,
          sentAt: new Date().toISOString(),
        },
      }
    } catch (error) {
      console.error("Error sending email:", error)
      throw error
    }
  },
}

export default apiService

