"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Workspace interface
interface Workspace {
  id: string
  name: string
  description?: string
  createdAt: string
  updatedAt: string
  members: WorkspaceMember[]
  ownerId: string
}

// Workspace member interface
interface WorkspaceMember {
  id: string
  userId: string
  email: string
  role: "owner" | "admin" | "member" | "viewer"
  joinedAt: string
}

// Create workspace data interface
interface CreateWorkspaceData {
  name: string
  description?: string
}

// Update workspace data interface
interface UpdateWorkspaceData {
  name: string
  description?: string
}

// Invite member data interface
interface InviteMemberData {
  email: string
  role: "admin" | "member" | "viewer"
}

// Workspace context interface
interface WorkspaceContextType {
  workspaces: Workspace[]
  currentWorkspace: Workspace | null
  getWorkspace: (id: string) => Promise<Workspace | null>
  createWorkspace: (data: CreateWorkspaceData) => Promise<Workspace>
  updateWorkspace: (id: string, data: UpdateWorkspaceData) => Promise<Workspace>
  deleteWorkspace: (id: string) => Promise<void>
  setCurrentWorkspace: (id: string) => void
  inviteMember: (workspaceId: string, data: InviteMemberData) => Promise<void>
  removeMember: (workspaceId: string, userId: string) => Promise<void>
  updateMemberRole: (workspaceId: string, userId: string, role: "admin" | "member" | "viewer") => Promise<void>
}

// Create context
const WorkspaceContext = createContext<WorkspaceContextType | undefined>(undefined)

// Generate 1000 mock workspaces
const generateMockWorkspaces = (): Workspace[] => {
  const mockWorkspaces: Workspace[] = []

  // Add the initial 3 workspaces
  mockWorkspaces.push(
    {
      id: "ws-001",
      name: "Marketing Team",
      description: "Workspace for marketing team workflows",
      createdAt: "2023-05-15T10:30:00Z",
      updatedAt: "2023-05-15T10:30:00Z",
      ownerId: "1",
      members: [
        {
          id: "mem-001",
          userId: "1",
          email: "admin@example.com",
          role: "owner",
          joinedAt: "2023-05-15T10:30:00Z",
        },
        {
          id: "mem-002",
          userId: "2",
          email: "marketing@example.com",
          role: "admin",
          joinedAt: "2023-05-16T10:30:00Z",
        },
      ],
    },
    {
      id: "ws-002",
      name: "Development Team",
      description: "Workspace for development team workflows",
      createdAt: "2023-06-20T14:45:00Z",
      updatedAt: "2023-06-20T14:45:00Z",
      ownerId: "1",
      members: [
        {
          id: "mem-003",
          userId: "1",
          email: "admin@example.com",
          role: "owner",
          joinedAt: "2023-06-20T14:45:00Z",
        },
        {
          id: "mem-004",
          userId: "3",
          email: "developer@example.com",
          role: "member",
          joinedAt: "2023-06-21T14:45:00Z",
        },
      ],
    },
    {
      id: "ws-003",
      name: "Sales Team",
      description: "Workspace for sales team workflows",
      createdAt: "2023-07-05T09:15:00Z",
      updatedAt: "2023-07-05T09:15:00Z",
      ownerId: "1",
      members: [
        {
          id: "mem-005",
          userId: "1",
          email: "admin@example.com",
          role: "owner",
          joinedAt: "2023-07-05T09:15:00Z",
        },
        {
          id: "mem-006",
          userId: "4",
          email: "sales@example.com",
          role: "admin",
          joinedAt: "2023-07-06T09:15:00Z",
        },
      ],
    },
  )

  // Generate additional 997 workspaces
  for (let i = 4; i <= 1000; i++) {
    const id = `ws-${i.toString().padStart(3, "0")}`
    const randomDate = new Date(Date.now() - Math.floor(Math.random() * 10000000000)).toISOString()

    mockWorkspaces.push({
      id,
      name: `Workspace ${i}`,
      description: `Description for workspace ${i}`,
      createdAt: randomDate,
      updatedAt: randomDate,
      ownerId: "1",
      members: [
        {
          id: `mem-${i * 2 - 1}`,
          userId: "1",
          email: "admin@example.com",
          role: "owner",
          joinedAt: randomDate,
        },
        {
          id: `mem-${i * 2}`,
          userId: `${Math.floor(Math.random() * 10) + 2}`,
          email: `user${Math.floor(Math.random() * 10) + 2}@example.com`,
          role: Math.random() > 0.7 ? "admin" : Math.random() > 0.5 ? "member" : "viewer",
          joinedAt: randomDate,
        },
      ],
    })
  }

  return mockWorkspaces
}

// Workspace provider component
export function WorkspaceProvider({ children }: { children: ReactNode }) {
  // Workspaces state
  const [workspaces, setWorkspaces] = useState<Workspace[]>([])
  const [currentWorkspace, setCurrentWorkspaceState] = useState<Workspace | null>(null)

  // Load workspaces from localStorage or use initial data on mount
  useEffect(() => {
    const storedWorkspaces = localStorage.getItem("workspaces")
    if (storedWorkspaces) {
      setWorkspaces(JSON.parse(storedWorkspaces))
    } else {
      const mockWorkspaces = generateMockWorkspaces()
      setWorkspaces(mockWorkspaces)
      localStorage.setItem("workspaces", JSON.stringify(mockWorkspaces))
    }

    // Set current workspace from localStorage if available
    const storedCurrentWorkspaceId = localStorage.getItem("currentWorkspaceId")
    if (storedCurrentWorkspaceId) {
      const workspace = JSON.parse(storedWorkspaces || "[]").find((ws: Workspace) => ws.id === storedCurrentWorkspaceId)
      if (workspace) {
        setCurrentWorkspaceState(workspace)
      }
    }
  }, [])

  // Get a specific workspace by ID
  const getWorkspace = async (id: string): Promise<Workspace | null> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 300))

    const workspace = workspaces.find((ws) => ws.id === id)
    return workspace || null
  }

  // Create a new workspace
  const createWorkspace = async (data: CreateWorkspaceData): Promise<Workspace> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const newWorkspace: Workspace = {
      id: `ws-${Date.now().toString().slice(-6)}`,
      name: data.name,
      description: data.description,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ownerId: "1", // Current user ID
      members: [
        {
          id: `mem-${Date.now().toString().slice(-6)}`,
          userId: "1", // Current user ID
          email: "admin@example.com", // Current user email
          role: "owner",
          joinedAt: new Date().toISOString(),
        },
      ],
    }

    const updatedWorkspaces = [...workspaces, newWorkspace]
    setWorkspaces(updatedWorkspaces)
    localStorage.setItem("workspaces", JSON.stringify(updatedWorkspaces))

    return newWorkspace
  }

  // Update an existing workspace
  const updateWorkspace = async (id: string, data: UpdateWorkspaceData): Promise<Workspace> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const workspaceIndex = workspaces.findIndex((ws) => ws.id === id)

    if (workspaceIndex === -1) {
      throw new Error("Workspace not found")
    }

    const updatedWorkspace: Workspace = {
      ...workspaces[workspaceIndex],
      name: data.name,
      description: data.description,
      updatedAt: new Date().toISOString(),
    }

    const updatedWorkspaces = [...workspaces]
    updatedWorkspaces[workspaceIndex] = updatedWorkspace

    setWorkspaces(updatedWorkspaces)
    localStorage.setItem("workspaces", JSON.stringify(updatedWorkspaces))

    // Update current workspace if it's the one being updated
    if (currentWorkspace && currentWorkspace.id === id) {
      setCurrentWorkspaceState(updatedWorkspace)
    }

    return updatedWorkspace
  }

  // Delete a workspace
  const deleteWorkspace = async (id: string): Promise<void> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const updatedWorkspaces = workspaces.filter((ws) => ws.id !== id)
    setWorkspaces(updatedWorkspaces)
    localStorage.setItem("workspaces", JSON.stringify(updatedWorkspaces))

    // Clear current workspace if it's the one being deleted
    if (currentWorkspace && currentWorkspace.id === id) {
      setCurrentWorkspaceState(null)
      localStorage.removeItem("currentWorkspaceId")
    }
  }

  // Set current workspace
  const setCurrentWorkspace = (id: string) => {
    const workspace = workspaces.find((ws) => ws.id === id)
    if (workspace) {
      setCurrentWorkspaceState(workspace)
      localStorage.setItem("currentWorkspaceId", id)
    }
  }

  // Invite a member to a workspace
  const inviteMember = async (workspaceId: string, data: InviteMemberData): Promise<void> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const workspaceIndex = workspaces.findIndex((ws) => ws.id === workspaceId)

    if (workspaceIndex === -1) {
      throw new Error("Workspace not found")
    }

    const newMember: WorkspaceMember = {
      id: `mem-${Date.now().toString().slice(-6)}`,
      userId: `user-${Date.now().toString().slice(-6)}`, // In a real app, this would be the user's ID
      email: data.email,
      role: data.role,
      joinedAt: new Date().toISOString(),
    }

    const updatedWorkspace = {
      ...workspaces[workspaceIndex],
      members: [...workspaces[workspaceIndex].members, newMember],
      updatedAt: new Date().toISOString(),
    }

    const updatedWorkspaces = [...workspaces]
    updatedWorkspaces[workspaceIndex] = updatedWorkspace

    setWorkspaces(updatedWorkspaces)
    localStorage.setItem("workspaces", JSON.stringify(updatedWorkspaces))

    // Update current workspace if it's the one being updated
    if (currentWorkspace && currentWorkspace.id === workspaceId) {
      setCurrentWorkspaceState(updatedWorkspace)
    }
  }

  // Remove a member from a workspace
  const removeMember = async (workspaceId: string, userId: string): Promise<void> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const workspaceIndex = workspaces.findIndex((ws) => ws.id === workspaceId)

    if (workspaceIndex === -1) {
      throw new Error("Workspace not found")
    }

    // Don't allow removing the owner
    if (workspaces[workspaceIndex].ownerId === userId) {
      throw new Error("Cannot remove the workspace owner")
    }

    const updatedWorkspace = {
      ...workspaces[workspaceIndex],
      members: workspaces[workspaceIndex].members.filter((member) => member.userId !== userId),
      updatedAt: new Date().toISOString(),
    }

    const updatedWorkspaces = [...workspaces]
    updatedWorkspaces[workspaceIndex] = updatedWorkspace

    setWorkspaces(updatedWorkspaces)
    localStorage.setItem("workspaces", JSON.stringify(updatedWorkspaces))

    // Update current workspace if it's the one being updated
    if (currentWorkspace && currentWorkspace.id === workspaceId) {
      setCurrentWorkspaceState(updatedWorkspace)
    }
  }

  // Update a member's role in a workspace
  const updateMemberRole = async (
    workspaceId: string,
    userId: string,
    role: "admin" | "member" | "viewer",
  ): Promise<void> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const workspaceIndex = workspaces.findIndex((ws) => ws.id === workspaceId)

    if (workspaceIndex === -1) {
      throw new Error("Workspace not found")
    }

    // Don't allow changing the owner's role
    if (workspaces[workspaceIndex].ownerId === userId) {
      throw new Error("Cannot change the workspace owner's role")
    }

    const updatedWorkspace = {
      ...workspaces[workspaceIndex],
      members: workspaces[workspaceIndex].members.map((member) =>
        member.userId === userId ? { ...member, role } : member,
      ),
      updatedAt: new Date().toISOString(),
    }

    const updatedWorkspaces = [...workspaces]
    updatedWorkspaces[workspaceIndex] = updatedWorkspace

    setWorkspaces(updatedWorkspaces)
    localStorage.setItem("workspaces", JSON.stringify(updatedWorkspaces))

    // Update current workspace if it's the one being updated
    if (currentWorkspace && currentWorkspace.id === workspaceId) {
      setCurrentWorkspaceState(updatedWorkspace)
    }
  }

  return (
    <WorkspaceContext.Provider
      value={{
        workspaces,
        currentWorkspace,
        getWorkspace,
        createWorkspace,
        updateWorkspace,
        deleteWorkspace,
        setCurrentWorkspace,
        inviteMember,
        removeMember,
        updateMemberRole,
      }}
    >
      {children}
    </WorkspaceContext.Provider>
  )
}

// Custom hook to use workspace context
export function useWorkspaces() {
  const context = useContext(WorkspaceContext)
  if (context === undefined) {
    throw new Error("useWorkspaces must be used within a WorkspaceProvider")
  }
  return context
}

