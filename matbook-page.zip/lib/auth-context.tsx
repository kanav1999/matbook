"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// User interface
interface User {
  id: string
  email: string
}

// Auth context interface
interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<void>
  logout: () => void
}

// Create context
const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Auth provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  // User state
  const [user, setUser] = useState<User | null>(null)

  // Check for stored user on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
  }, [])

  // Login function
  const login = async (email: string, password: string) => {
    // Mock authentication - in a real app, this would call an API
    if (email && password) {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      const user = { id: "1", email }
      setUser(user)
      localStorage.setItem("user", JSON.stringify(user))
      return
    }

    throw new Error("Invalid credentials")
  }

  // Logout function
  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>
}

// Custom hook to use auth context
export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

