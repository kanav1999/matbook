"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Node, Edge } from "reactflow"
import apiService from "./api-service"

// Workflow interface
interface Workflow {
  id: string
  name: string
  description?: string
  status: "passed" | "failed" | "draft"
  createdAt: string
  updatedAt: string
  nodes: Node[]
  edges: Edge[]
  workspaceId: string
}

// Create workflow data interface
interface CreateWorkflowData {
  name: string
  description?: string
  nodes: Node[]
  edges: Edge[]
  workspaceId?: string
}

// Update workflow data interface
interface UpdateWorkflowData {
  name: string
  description?: string
  nodes: Node[]
  edges: Edge[]
}

// Workflow context interface
interface WorkflowContextType {
  workflows: Workflow[]
  getWorkflow: (id: string) => Promise<Workflow | null>
  createWorkflow: (data: CreateWorkflowData) => Promise<Workflow>
  updateWorkflow: (id: string, data: UpdateWorkflowData) => Promise<Workflow>
  deleteWorkflow: (id: string) => Promise<void>
  executeWorkflow: (id: string) => Promise<void>
  duplicateWorkflow: (id: string, targetWorkspaceId?: string) => Promise<Workflow>
  getWorkflowsByWorkspace: (workspaceId: string) => Workflow[]
}

// Create context
const WorkflowContext = createContext<WorkflowContextType | undefined>(undefined)

// Generate 1000 mock workflows
const generateMockWorkflows = (): Workflow[] => {
  const statuses: ("passed" | "failed" | "draft")[] = ["passed", "failed", "draft"]
  const mockWorkflows: Workflow[] = []

  // Add the initial 3 workflows
  mockWorkflows.push(
    {
      id: "wf-001",
      name: "Customer Onboarding",
      description: "Process for new customer registration",
      status: "passed",
      createdAt: "2023-05-15T10:30:00Z",
      updatedAt: "2023-05-15T10:30:00Z",
      workspaceId: "ws-001",
      nodes: [
        {
          id: "start",
          type: "start",
          position: { x: 250, y: 50 },
          data: { label: "Start" },
        },
        {
          id: "api-1",
          type: "api",
          position: { x: 250, y: 150 },
          data: {
            label: "Verify Customer",
            url: "https://beeceptor.com/console/sample-api-for-testing/users",
            method: "POST",
            body: JSON.stringify({ action: "verify" }),
          },
        },
        {
          id: "email-1",
          type: "email",
          position: { x: 250, y: 250 },
          data: {
            label: "Welcome Email",
            to: "customer@example.com",
            subject: "Welcome to Our Service",
            body: "Thank you for registering with our service!",
          },
        },
        {
          id: "end",
          type: "end",
          position: { x: 250, y: 350 },
          data: { label: "End" },
        },
      ],
      edges: [
        { id: "e1-2", source: "start", target: "api-1", animated: true },
        { id: "e2-3", source: "api-1", target: "email-1", animated: true },
        { id: "e3-4", source: "email-1", target: "end", animated: true },
      ],
    },
    {
      id: "wf-002",
      name: "Payment Processing",
      description: "Handle customer payments",
      status: "failed",
      createdAt: "2023-06-20T14:45:00Z",
      updatedAt: "2023-06-20T14:45:00Z",
      workspaceId: "ws-001",
      nodes: [
        {
          id: "start",
          type: "start",
          position: { x: 250, y: 50 },
          data: { label: "Start" },
        },
        {
          id: "api-1",
          type: "api",
          position: { x: 250, y: 150 },
          data: {
            label: "Process Payment",
            url: "https://beeceptor.com/console/sample-api-for-testing/payments",
            method: "POST",
            body: JSON.stringify({ amount: 100, currency: "USD" }),
          },
        },
        {
          id: "end",
          type: "end",
          position: { x: 250, y: 250 },
          data: { label: "End" },
        },
      ],
      edges: [
        { id: "e1-2", source: "start", target: "api-1", animated: true },
        { id: "e2-3", source: "api-1", target: "end", animated: true },
      ],
    },
    {
      id: "wf-003",
      name: "Order Fulfillment",
      description: "Process customer orders",
      status: "draft",
      createdAt: "2023-07-05T09:15:00Z",
      updatedAt: "2023-07-05T09:15:00Z",
      workspaceId: "ws-002",
      nodes: [
        {
          id: "start",
          type: "start",
          position: { x: 250, y: 50 },
          data: { label: "Start" },
        },
        {
          id: "api-1",
          type: "api",
          position: { x: 250, y: 150 },
          data: {
            label: "Check Inventory",
            url: "https://beeceptor.com/console/sample-api-for-testing/inventory",
            method: "GET",
          },
        },
        {
          id: "api-2",
          type: "api",
          position: { x: 250, y: 250 },
          data: {
            label: "Create Shipment",
            url: "https://beeceptor.com/console/sample-api-for-testing/shipments",
            method: "POST",
            body: JSON.stringify({ orderId: "12345", items: [{ id: "item-1", quantity: 1 }] }),
          },
        },
        {
          id: "email-1",
          type: "email",
          position: { x: 250, y: 350 },
          data: {
            label: "Order Confirmation",
            to: "customer@example.com",
            subject: "Your Order Has Shipped",
            body: "Your order has been shipped and will arrive in 3-5 business days.",
          },
        },
        {
          id: "end",
          type: "end",
          position: { x: 250, y: 450 },
          data: { label: "End" },
        },
      ],
      edges: [
        { id: "e1-2", source: "start", target: "api-1", animated: true },
        { id: "e2-3", source: "api-1", target: "api-2", animated: true },
        { id: "e3-4", source: "api-2", target: "email-1", animated: true },
        { id: "e4-5", source: "email-1", target: "end", animated: true },
      ],
    },
  )

  // Generate additional 997 workflows
  for (let i = 4; i <= 1000; i++) {
    const id = `wf-${i.toString().padStart(3, "0")}`
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)]
    const randomDate = new Date(Date.now() - Math.floor(Math.random() * 10000000000)).toISOString()
    const workspaceId = `ws-${Math.floor(Math.random() * 1000 + 1)
      .toString()
      .padStart(3, "0")}`

    mockWorkflows.push({
      id,
      name: `Workflow ${i}`,
      description: `Description for workflow ${i}`,
      status: randomStatus,
      createdAt: randomDate,
      updatedAt: randomDate,
      workspaceId,
      nodes: [
        {
          id: "start",
          type: "start",
          position: { x: 250, y: 50 },
          data: { label: "Start" },
        },
        {
          id: "end",
          type: "end",
          position: { x: 250, y: 150 },
          data: { label: "End" },
        },
      ],
      edges: [{ id: "e1-2", source: "start", target: "end", animated: true }],
    })
  }

  return mockWorkflows
}

// Workflow provider component
export function WorkflowProvider({ children }: { children: ReactNode }) {
  // Workflows state
  const [workflows, setWorkflows] = useState<Workflow[]>([])

  // Load workflows from localStorage or use initial data on mount
  useEffect(() => {
    const storedWorkflows = localStorage.getItem("workflows")
    if (storedWorkflows) {
      setWorkflows(JSON.parse(storedWorkflows))
    } else {
      const mockWorkflows = generateMockWorkflows()
      setWorkflows(mockWorkflows)
      localStorage.setItem("workflows", JSON.stringify(mockWorkflows))
    }
  }, [])

  // Get a specific workflow by ID
  const getWorkflow = async (id: string): Promise<Workflow | null> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 300))

    const workflow = workflows.find((wf) => wf.id === id)
    return workflow || null
  }

  // Get workflows by workspace ID
  const getWorkflowsByWorkspace = (workspaceId: string): Workflow[] => {
    return workflows.filter((wf) => wf.workspaceId === workspaceId)
  }

  // Create a new workflow
  const createWorkflow = async (data: CreateWorkflowData): Promise<Workflow> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const newWorkflow: Workflow = {
      id: `wf-${Date.now().toString().slice(-6)}`,
      name: data.name,
      description: data.description,
      status: "draft",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      nodes: data.nodes,
      edges: data.edges,
      workspaceId: data.workspaceId || "ws-001", // Default to first workspace if not specified
    }

    const updatedWorkflows = [...workflows, newWorkflow]
    setWorkflows(updatedWorkflows)
    localStorage.setItem("workflows", JSON.stringify(updatedWorkflows))

    return newWorkflow
  }

  // Update an existing workflow
  const updateWorkflow = async (id: string, data: UpdateWorkflowData): Promise<Workflow> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const workflowIndex = workflows.findIndex((wf) => wf.id === id)

    if (workflowIndex === -1) {
      throw new Error("Workflow not found")
    }

    const updatedWorkflow: Workflow = {
      ...workflows[workflowIndex],
      name: data.name,
      description: data.description,
      updatedAt: new Date().toISOString(),
      nodes: data.nodes,
      edges: data.edges,
    }

    const updatedWorkflows = [...workflows]
    updatedWorkflows[workflowIndex] = updatedWorkflow

    setWorkflows(updatedWorkflows)
    localStorage.setItem("workflows", JSON.stringify(updatedWorkflows))

    return updatedWorkflow
  }

  // Delete a workflow
  const deleteWorkflow = async (id: string): Promise<void> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const updatedWorkflows = workflows.filter((wf) => wf.id !== id)
    setWorkflows(updatedWorkflows)
    localStorage.setItem("workflows", JSON.stringify(updatedWorkflows))
  }

  // Execute a workflow
  const executeWorkflow = async (id: string): Promise<void> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const workflowIndex = workflows.findIndex((wf) => wf.id === id)

    if (workflowIndex === -1) {
      throw new Error("Workflow not found")
    }

    const workflow = workflows[workflowIndex]

    try {
      // Execute the workflow nodes in sequence
      let apiResponse = null

      // Find the execution path (from start to end)
      const executionPath = findExecutionPath(workflow.nodes, workflow.edges)

      // Execute each node in the path
      for (const node of executionPath) {
        if (node.type === "api") {
          // Execute API call
          apiResponse = await apiService.executeApiCall(
            node.data.url,
            node.data.method,
            node.data.body ? JSON.parse(node.data.body) : undefined,
          )
          console.log("API response:", apiResponse)
        } else if (node.type === "email") {
          // Send email with API response if available
          let emailBody = node.data.body || ""

          if (apiResponse) {
            emailBody += "\n\nAPI Response:\n" + JSON.stringify(apiResponse, null, 2)
          }

          await apiService.sendEmail(node.data.to, node.data.subject, emailBody)
          console.log("Email sent to:", node.data.to)
        }
      }

      // Mark workflow as passed
      const updatedWorkflow: Workflow = {
        ...workflows[workflowIndex],
        status: "passed",
        updatedAt: new Date().toISOString(),
      }

      const updatedWorkflows = [...workflows]
      updatedWorkflows[workflowIndex] = updatedWorkflow

      setWorkflows(updatedWorkflows)
      localStorage.setItem("workflows", JSON.stringify(updatedWorkflows))
    } catch (error) {
      console.error("Error executing workflow:", error)

      // Mark workflow as failed
      const updatedWorkflow: Workflow = {
        ...workflows[workflowIndex],
        status: "failed",
        updatedAt: new Date().toISOString(),
      }

      const updatedWorkflows = [...workflows]
      updatedWorkflows[workflowIndex] = updatedWorkflow

      setWorkflows(updatedWorkflows)
      localStorage.setItem("workflows", JSON.stringify(updatedWorkflows))

      throw error
    }
  }

  // Helper function to find execution path from start to end
  const findExecutionPath = (nodes: Node[], edges: Edge[]): Node[] => {
    const path: Node[] = []
    const nodeMap = new Map<string, Node>()

    // Create a map of node IDs to nodes for easy lookup
    nodes.forEach((node) => nodeMap.set(node.id, node))

    // Find the start node
    const startNode = nodes.find((node) => node.type === "start")
    if (!startNode) return path

    path.push(startNode)

    // Traverse the graph from start to end
    let currentNodeId = startNode.id

    while (currentNodeId) {
      // Find the next edge from the current node
      const nextEdge = edges.find((edge) => edge.source === currentNodeId)

      if (!nextEdge) break

      // Get the target node
      const nextNode = nodeMap.get(nextEdge.target)
      if (!nextNode) break

      path.push(nextNode)
      currentNodeId = nextNode.id

      // If we reached the end node, stop
      if (nextNode.type === "end") break
    }

    return path
  }

  // Duplicate a workflow (optionally to another workspace)
  const duplicateWorkflow = async (id: string, targetWorkspaceId?: string): Promise<Workflow> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const sourceWorkflow = workflows.find((wf) => wf.id === id)
    if (!sourceWorkflow) {
      throw new Error("Source workflow not found")
    }

    const newWorkflow: Workflow = {
      ...sourceWorkflow,
      id: `wf-${Date.now().toString().slice(-6)}`,
      name: `Copy of ${sourceWorkflow.name}`,
      status: "draft",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      workspaceId: targetWorkspaceId || sourceWorkflow.workspaceId,
    }

    const updatedWorkflows = [...workflows, newWorkflow]
    setWorkflows(updatedWorkflows)
    localStorage.setItem("workflows", JSON.stringify(updatedWorkflows))

    return newWorkflow
  }

  return (
    <WorkflowContext.Provider
      value={{
        workflows,
        getWorkflow,
        createWorkflow,
        updateWorkflow,
        deleteWorkflow,
        executeWorkflow,
        duplicateWorkflow,
        getWorkflowsByWorkspace,
      }}
    >
      {children}
    </WorkflowContext.Provider>
  )
}

// Custom hook to use workflow context
export function useWorkflows() {
  const context = useContext(WorkflowContext)
  if (context === undefined) {
    throw new Error("useWorkflows must be used within a WorkflowProvider")
  }
  return context
}

