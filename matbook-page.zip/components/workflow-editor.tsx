"use client"

import { useState, useCallback, useEffect } from "react"
import ReactFlow, { Background, Controls, MiniMap, addEdge, useNodesState, useEdgesState, Panel } from "reactflow"
import "reactflow/dist/style.css"
import { ZoomIn, ZoomOut } from "lucide-react"
import StartNode from "@/components/nodes/start-node"
import EndNode from "@/components/nodes/end-node"
import ApiNode from "@/components/nodes/api-node"
import EmailNode from "@/components/nodes/email-node"
import NodePanel from "@/components/node-panel"

// Define node types for the workflow editor
const nodeTypes = {
  start: StartNode,
  end: EndNode,
  api: ApiNode,
  email: EmailNode,
}

export default function WorkflowEditor({ initialNodes, initialEdges, onNodesChange, onEdgesChange }) {
  // ReactFlow state
  const [nodes, setNodes, onNodesChangeInternal] = useNodesState(initialNodes || [])
  const [edges, setEdges, onEdgesChangeInternal] = useEdgesState(initialEdges || [])
  const [selectedNode, setSelectedNode] = useState(null)
  const [reactFlowInstance, setReactFlowInstance] = useState(null)

  // Update parent component when nodes or edges change
  useEffect(() => {
    if (onNodesChange) {
      onNodesChange(nodes)
    }
  }, [nodes, onNodesChange])

  useEffect(() => {
    if (onEdgesChange) {
      onEdgesChange(edges)
    }
  }, [edges, onEdgesChange])

  // Update local state when props change
  useEffect(() => {
    if (initialNodes) {
      setNodes(initialNodes)
    }
  }, [initialNodes, setNodes])

  useEffect(() => {
    if (initialEdges) {
      setEdges(initialEdges)
    }
  }, [initialEdges, setEdges])

  // Handle connection between nodes
  const onConnect = useCallback(
    (params) => {
      setEdges((eds) => addEdge({ ...params, animated: true }, eds))
    },
    [setEdges],
  )

  // Handle node selection
  const onNodeClick = useCallback((_, node) => {
    setSelectedNode(node)
  }, [])

  // Clear node selection when clicking on the canvas
  const onPaneClick = useCallback(() => {
    setSelectedNode(null)
  }, [])

  // Update node data when properties change
  const updateNodeData = useCallback(
    (id, data) => {
      setNodes((nds) =>
        nds.map((node) => {
          if (node.id === id) {
            return {
              ...node,
              data: {
                ...node.data,
                ...data,
              },
            }
          }
          return node
        }),
      )
    },
    [setNodes],
  )

  // Zoom controls
  const handleZoomIn = () => {
    if (reactFlowInstance) {
      reactFlowInstance.zoomIn()
    }
  }

  const handleZoomOut = () => {
    if (reactFlowInstance) {
      reactFlowInstance.zoomOut()
    }
  }

  return (
    <div style={{ width: "100%", height: "100%", position: "relative" }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChangeInternal}
        onEdgesChange={onEdgesChangeInternal}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        onPaneClick={onPaneClick}
        nodeTypes={nodeTypes}
        fitView
        onInit={setReactFlowInstance}
      >
        <Background />
        <Controls />
        <MiniMap />
        <Panel position="bottom-right">
          <div className="flex flex-col gap-2">
            <button className="p-1 bg-white border border-gray-300 rounded" onClick={handleZoomIn}>
              <ZoomIn className="h-4 w-4" />
            </button>
            <button className="p-1 bg-white border border-gray-300 rounded" onClick={handleZoomOut}>
              <ZoomOut className="h-4 w-4" />
            </button>
          </div>
        </Panel>
      </ReactFlow>

      {/* Node properties panel */}
      {selectedNode && (
        <div className="absolute top-0 right-0 w-64 bg-white border-l border-gray-200 h-full p-4 overflow-y-auto">
          <NodePanel node={selectedNode} updateNodeData={(data) => updateNodeData(selectedNode.id, data)} />
        </div>
      )}
    </div>
  )
}

