"use client"

import { useRef, useEffect, useState } from "react"
import { ZoomIn, ZoomOut, Move } from "lucide-react"

export default function SimpleWorkflowEditor({
  nodes,
  connections,
  onNodesChange,
  onConnectionsChange,
  onSelectNode,
  selectedNode,
}) {
  const canvasRef = useRef(null)
  const containerRef = useRef(null)
  const [dragging, setDragging] = useState(null)
  const [connecting, setConnecting] = useState(null)
  const [hoveredNode, setHoveredNode] = useState(null)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isPanning, setIsPanning] = useState(false)
  const [panStart, setPanStart] = useState({ x: 0, y: 0 })

  // Draw the workflow on canvas
  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    const container = containerRef.current

    // Set canvas size to match container
    canvas.width = container.clientWidth
    canvas.height = container.clientHeight

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Apply zoom and pan transformations
    ctx.save()
    ctx.translate(pan.x, pan.y)
    ctx.scale(zoom, zoom)

    // Draw connections
    ctx.strokeStyle = "#888"
    ctx.lineWidth = 2

    connections.forEach((conn) => {
      const sourceNode = nodes.find((n) => n.id === conn.source)
      const targetNode = nodes.find((n) => n.id === conn.target)

      if (sourceNode && targetNode) {
        // Calculate connection points (bottom of source, top of target)
        const sourceX = sourceNode.x + 75 // middle of node
        const sourceY = sourceNode.y + 40 // bottom of node
        const targetX = targetNode.x + 75 // middle of node
        const targetY = targetNode.y // top of node

        // Draw line with arrow
        ctx.beginPath()
        ctx.moveTo(sourceX, sourceY)

        // Draw curved line
        const controlPointY = (sourceY + targetY) / 2
        ctx.bezierCurveTo(sourceX, controlPointY, targetX, controlPointY, targetX, targetY)

        ctx.stroke()

        // Draw arrow at target
        const arrowSize = 8
        const angle = Math.atan2(targetY - controlPointY, targetX - sourceX)

        ctx.beginPath()
        ctx.moveTo(targetX, targetY)
        ctx.lineTo(
          targetX - arrowSize * Math.cos(angle - Math.PI / 6),
          targetY - arrowSize * Math.sin(angle - Math.PI / 6),
        )
        ctx.lineTo(
          targetX - arrowSize * Math.cos(angle + Math.PI / 6),
          targetY - arrowSize * Math.sin(angle + Math.PI / 6),
        )
        ctx.closePath()
        ctx.fillStyle = "#888"
        ctx.fill()
      }
    })

    // Draw temporary connection line if connecting
    if (connecting) {
      const sourceNode = nodes.find((n) => n.id === connecting.source)

      if (sourceNode) {
        ctx.strokeStyle = "#888"
        ctx.lineWidth = 2
        ctx.setLineDash([5, 3])

        ctx.beginPath()
        ctx.moveTo(sourceNode.x + 75, sourceNode.y + 40)
        ctx.lineTo((connecting.mouseX - pan.x) / zoom, (connecting.mouseY - pan.y) / zoom)
        ctx.stroke()

        ctx.setLineDash([])
      }
    }

    ctx.restore()
  }, [nodes, connections, connecting, hoveredNode, zoom, pan])

  // Handle mouse down on canvas
  const handleMouseDown = (e) => {
    const rect = canvasRef.current.getBoundingClientRect()
    const mouseX = (e.clientX - rect.left - pan.x) / zoom
    const mouseY = (e.clientY - rect.top - pan.y) / zoom

    // Check if space key is pressed for panning
    if (e.buttons === 4 || (e.buttons === 1 && e.altKey)) {
      setIsPanning(true)
      setPanStart({ x: e.clientX, y: e.clientY })
      return
    }

    // Check if clicked on a node
    const clickedNode = nodes.find(
      (node) => mouseX >= node.x && mouseX <= node.x + 150 && mouseY >= node.y && mouseY <= node.y + 40,
    )

    if (clickedNode) {
      // Select node
      onSelectNode(clickedNode)

      // Check if clicked on output handle (bottom of node)
      if (mouseY >= clickedNode.y + 30 && mouseY <= clickedNode.y + 40) {
        // Start connection from this node
        setConnecting({
          source: clickedNode.id,
          mouseX: e.clientX,
          mouseY: e.clientY,
        })
      } else {
        // Start dragging this node
        setDragging({
          id: clickedNode.id,
          offsetX: mouseX - clickedNode.x,
          offsetY: mouseY - clickedNode.y,
        })
      }
    } else {
      // Clicked on empty space, deselect
      onSelectNode(null)
    }
  }

  // Handle mouse move on canvas
  const handleMouseMove = (e) => {
    const rect = canvasRef.current.getBoundingClientRect()
    const mouseX = (e.clientX - rect.left - pan.x) / zoom
    const mouseY = (e.clientY - rect.top - pan.y) / zoom

    // Handle panning
    if (isPanning) {
      setPan({
        x: pan.x + (e.clientX - panStart.x),
        y: pan.y + (e.clientY - panStart.y),
      })
      setPanStart({ x: e.clientX, y: e.clientY })
      return
    }

    // Update node position if dragging
    if (dragging) {
      const newNodes = nodes.map((node) => {
        if (node.id === dragging.id) {
          return {
            ...node,
            x: mouseX - dragging.offsetX,
            y: mouseY - dragging.offsetY,
          }
        }
        return node
      })

      onNodesChange(newNodes)
    }

    // Update connecting line if connecting
    if (connecting) {
      setConnecting({
        ...connecting,
        mouseX: e.clientX,
        mouseY: e.clientY,
      })
    }

    // Check for hover over nodes
    const hovered = nodes.find(
      (node) => mouseX >= node.x && mouseX <= node.x + 150 && mouseY >= node.y && mouseY <= node.y + 40,
    )

    setHoveredNode(hovered)
  }

  // Handle mouse up on canvas
  const handleMouseUp = (e) => {
    // Stop panning
    if (isPanning) {
      setIsPanning(false)
      return
    }

    // If connecting, check if released on a node
    if (connecting) {
      const rect = canvasRef.current.getBoundingClientRect()
      const mouseX = (e.clientX - rect.left - pan.x) / zoom
      const mouseY = (e.clientY - rect.top - pan.y) / zoom

      // Find target node
      const targetNode = nodes.find(
        (node) =>
          mouseX >= node.x &&
          mouseX <= node.x + 150 &&
          mouseY >= node.y &&
          mouseY <= node.y + 40 &&
          node.id !== connecting.source, // Can't connect to self
      )

      if (targetNode) {
        // Check if connection already exists
        const connectionExists = connections.some(
          (conn) => conn.source === connecting.source && conn.target === targetNode.id,
        )

        // Check if this would create a cycle (except for end node)
        const wouldCreateCycle =
          targetNode.type !== "end" &&
          (targetNode.id === "start" || wouldCreateCycleCheck(targetNode.id, connecting.source))

        if (!connectionExists && !wouldCreateCycle) {
          // Add new connection
          onConnectionsChange([...connections, { source: connecting.source, target: targetNode.id }])
        }
      }
    }

    // Stop dragging/connecting
    setDragging(null)
    setConnecting(null)
  }

  // Check if adding a connection would create a cycle
  const wouldCreateCycleCheck = (from, to) => {
    // Find all connections from the 'from' node
    const outgoingConnections = connections.filter((conn) => conn.source === from)

    // Check if any of these connections lead to the 'to' node
    return outgoingConnections.some((conn) => conn.target === to || wouldCreateCycleCheck(conn.target, to))
  }

  // Handle zoom in
  const handleZoomIn = () => {
    setZoom(Math.min(zoom * 1.2, 3))
  }

  // Handle zoom out
  const handleZoomOut = () => {
    setZoom(Math.max(zoom / 1.2, 0.5))
  }

  // Handle reset view
  const handleResetView = () => {
    setZoom(1)
    setPan({ x: 0, y: 0 })
  }

  // Handle wheel zoom
  const handleWheel = (e) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault()
      const delta = e.deltaY < 0 ? 1.1 : 0.9
      const newZoom = Math.max(0.5, Math.min(3, zoom * delta))

      // Calculate zoom point (mouse position)
      const rect = canvasRef.current.getBoundingClientRect()
      const mouseX = e.clientX - rect.left
      const mouseY = e.clientY - rect.top

      // Calculate new pan position to zoom toward mouse position
      const newPan = {
        x: mouseX - (mouseX - pan.x) * (newZoom / zoom),
        y: mouseY - (mouseY - pan.y) * (newZoom / zoom),
      }

      setZoom(newZoom)
      setPan(newPan)
    }
  }

  // Render nodes as HTML elements
  const renderNodes = () => {
    return nodes.map((node) => {
      const isSelected = selectedNode && selectedNode.id === node.id
      const isHovered = hoveredNode && hoveredNode.id === node.id

      // Determine node color based on type
      let bgColor = "#abcd62" // default/start
      const textColor = "white"

      if (node.type === "end") bgColor = "#ee3425"
      else if (node.type === "api") bgColor = "#76a9ff"
      else if (node.type === "email") bgColor = "#6fa5ab"

      return (
        <div
          key={node.id}
          className={`absolute px-4 py-2 rounded-md shadow-md text-white select-none
            ${isSelected ? "ring-2 ring-blue-500" : ""}
            ${isHovered ? "cursor-move" : ""}`}
          style={{
            left: `${node.x * zoom + pan.x}px`,
            top: `${node.y * zoom + pan.y}px`,
            width: `${150 * zoom}px`,
            backgroundColor: bgColor,
            color: textColor,
            zIndex: isSelected ? 10 : 1,
            transform: `scale(${zoom})`,
            transformOrigin: "top left",
          }}
        >
          <div className="font-bold text-sm">{node.label}</div>

          {/* Show additional info for specific node types */}
          {node.type === "api" && node.url && <div className="text-xs truncate">{node.url}</div>}
          {node.type === "email" && node.to && <div className="text-xs truncate">To: {node.to}</div>}

          {/* Input handle (top) */}
          <div
            className="absolute w-4 h-4 bg-gray-200 rounded-full cursor-pointer"
            style={{
              top: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              display: node.type === "start" ? "none" : "block",
            }}
          />

          {/* Output handle (bottom) */}
          <div
            className="absolute w-4 h-4 bg-gray-200 rounded-full cursor-pointer"
            style={{
              bottom: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              display: node.type === "end" ? "none" : "block",
            }}
          />
        </div>
      )
    })
  }

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden">
      <canvas
        ref={canvasRef}
        className="absolute top-0 left-0 w-full h-full"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      />
      {renderNodes()}

      {/* Zoom controls */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-2 bg-white p-1 rounded-md shadow-md">
        <button onClick={handleZoomIn} className="p-1 hover:bg-gray-100 rounded" title="Zoom In">
          <ZoomIn className="h-5 w-5 text-gray-600" />
        </button>
        <button onClick={handleZoomOut} className="p-1 hover:bg-gray-100 rounded" title="Zoom Out">
          <ZoomOut className="h-5 w-5 text-gray-600" />
        </button>
        <button onClick={handleResetView} className="p-1 hover:bg-gray-100 rounded" title="Reset View">
          <Move className="h-5 w-5 text-gray-600" />
        </button>
      </div>

      {/* Instructions */}
      <div className="absolute top-2 left-2 bg-white/80 p-2 rounded text-xs text-gray-600">
        <p>Alt + Drag or Middle Mouse to pan</p>
        <p>Ctrl + Scroll to zoom</p>
      </div>

      {/* Zoom indicator */}
      <div className="absolute bottom-4 left-4 bg-white/80 px-2 py-1 rounded text-xs text-gray-600">
        {Math.round(zoom * 100)}%
      </div>
    </div>
  )
}

