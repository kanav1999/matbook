"use client"

import { useState, useEffect } from "react"

export default function NodePanel({ node, updateNodeData }) {
  // State for node data
  const [nodeData, setNodeData] = useState(node.data)

  // Update local state when node changes
  useEffect(() => {
    setNodeData(node.data)
  }, [node])

  // Handle input changes
  const handleChange = (key, value) => {
    const updatedData = {
      ...nodeData,
      [key]: value,
    }
    setNodeData(updatedData)
    updateNodeData(updatedData)
  }

  // Render different forms based on node type
  if (node.type === "start" || node.type === "end") {
    return (
      <div>
        <h3 className="font-medium mb-4">{node.data.label} Node</h3>
        <p className="text-sm text-gray-500">This is a {node.type} node. No configuration needed.</p>
      </div>
    )
  }

  if (node.type === "api") {
    return (
      <div className="space-y-4">
        <h3 className="font-medium">API Node Configuration</h3>

        <div>
          <label htmlFor="label" className="block text-sm font-medium text-gray-700 mb-1">
            Label
          </label>
          <input
            id="label"
            value={nodeData.label || ""}
            onChange={(e) => handleChange("label", e.target.value)}
            className="w-full p-2 border border-gray-300 rounded"
          />
        </div>

        <div>
          <label htmlFor="url" className="block text-sm font-medium text-gray-700 mb-1">
            URL
          </label>
          <input
            id="url"
            value={nodeData.url || ""}
            onChange={(e) => handleChange("url", e.target.value)}
            placeholder="https://api.example.com"
            className="w-full p-2 border border-gray-300 rounded"
          />
        </div>

        <div>
          <label htmlFor="method" className="block text-sm font-medium text-gray-700 mb-1">
            Method
          </label>
          <select
            id="method"
            value={nodeData.method || "GET"}
            onChange={(e) => handleChange("method", e.target.value)}
            className="w-full p-2 border border-gray-300 rounded"
          >
            <option value="GET">GET</option>
            <option value="POST">POST</option>
            <option value="PUT">PUT</option>
            <option value="DELETE">DELETE</option>
          </select>
        </div>

        <div>
          <label htmlFor="body" className="block text-sm font-medium text-gray-700 mb-1">
            Request Body (JSON)
          </label>
          <textarea
            id="body"
            value={nodeData.body || ""}
            onChange={(e) => handleChange("body", e.target.value)}
            placeholder="{}"
            className="w-full p-2 border border-gray-300 rounded"
            rows={5}
          />
        </div>
      </div>
    )
  }

  if (node.type === "email") {
    return (
      <div className="space-y-4">
        <h3 className="font-medium">Email Node Configuration</h3>

        <div>
          <label htmlFor="label" className="block text-sm font-medium text-gray-700 mb-1">
            Label
          </label>
          <input
            id="label"
            value={nodeData.label || ""}
            onChange={(e) => handleChange("label", e.target.value)}
            className="w-full p-2 border border-gray-300 rounded"
          />
        </div>

        <div>
          <label htmlFor="to" className="block text-sm font-medium text-gray-700 mb-1">
            To
          </label>
          <input
            id="to"
            value={nodeData.to || ""}
            onChange={(e) => handleChange("to", e.target.value)}
            placeholder="recipient@example.com"
            className="w-full p-2 border border-gray-300 rounded"
          />
        </div>

        <div>
          <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
            Subject
          </label>
          <input
            id="subject"
            value={nodeData.subject || ""}
            onChange={(e) => handleChange("subject", e.target.value)}
            placeholder="Email subject"
            className="w-full p-2 border border-gray-300 rounded"
          />
        </div>

        <div>
          <label htmlFor="body" className="block text-sm font-medium text-gray-700 mb-1">
            Email Body
          </label>
          <textarea
            id="body"
            value={nodeData.body || ""}
            onChange={(e) => handleChange("body", e.target.value)}
            placeholder="Email content..."
            className="w-full p-2 border border-gray-300 rounded"
            rows={5}
          />
        </div>
      </div>
    )
  }

  return <div className="text-center text-gray-500 py-8">Unknown node type: {node.type}</div>
}

