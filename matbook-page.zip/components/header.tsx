"use client"

import { useRouter } from "next/navigation"
import { LogOut } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import WorkspaceSelector from "./workspace-selector"

export default function Header() {
  // Router and auth context
  const router = useRouter()
  const { user, logout } = useAuth()

  // Handle logout
  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  return (
    <header className="bg-white border-b">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="bg-white rounded-full p-1 w-8 h-8 flex items-center justify-center">
            <div className="w-6 h-6 bg-[url('/highbridge-icon.png')] bg-contain bg-center bg-no-repeat"></div>
          </div>
          <span className="font-semibold text-lg">HighBridge</span>
        </div>

        {/* Workspace selector and logout button */}
        <div className="flex items-center gap-4">
          {user && <WorkspaceSelector />}

          {user && (
            <button
              onClick={handleLogout}
              className="text-gray-600 px-3 py-1 rounded hover:bg-gray-100 flex items-center gap-1"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          )}
        </div>
      </div>
    </header>
  )
}

