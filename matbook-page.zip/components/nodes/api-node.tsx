import { memo } from "react"
import { Handle, Position } from "reactflow"

// API node component for workflow
function ApiNode({ data }) {
  return (
    <div className="px-4 py-2 shadow-md rounded-md bg-[#76a9ff] text-white">
      <div className="font-bold">{data.label}</div>
      {/* Display API details if available */}
      {data.url && <div className="text-xs truncate max-w-[150px]">{data.url}</div>}
      {data.method && <div className="text-xs">{data.method}</div>}
      {/* Input and output handles */}
      <Handle type="target" position={Position.Top} id="a" className="w-2 h-2 bg-[#76a9ff]" />
      <Handle type="source" position={Position.Bottom} id="b" className="w-2 h-2 bg-[#76a9ff]" />
    </div>
  )
}

export default memo(ApiNode)

