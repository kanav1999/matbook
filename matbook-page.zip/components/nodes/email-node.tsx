import { memo } from "react"
import { Handle, Position } from "reactflow"

// Email node component for workflow
function EmailNode({ data }) {
  return (
    <div className="px-4 py-2 shadow-md rounded-md bg-[#6fa5ab] text-white">
      <div className="font-bold">{data.label}</div>
      {/* Display email details if available */}
      {data.to && <div className="text-xs truncate max-w-[150px]">To: {data.to}</div>}
      {data.subject && <div className="text-xs truncate max-w-[150px]">Subject: {data.subject}</div>}
      {/* Input and output handles */}
      <Handle type="target" position={Position.Top} id="a" className="w-2 h-2 bg-[#6fa5ab]" />
      <Handle type="source" position={Position.Bottom} id="b" className="w-2 h-2 bg-[#6fa5ab]" />
    </div>
  )
}

export default memo(EmailNode)

