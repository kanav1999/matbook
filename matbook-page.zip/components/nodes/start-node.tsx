import { memo } from "react"
import { Handle, Position } from "reactflow"

// Start node component for workflow
function StartNode({ data }) {
  return (
    <div className="px-4 py-2 shadow-md rounded-md bg-[#abcd62] text-white">
      <div className="font-bold">{data.label}</div>
      {/* Only source handle (output) for start node */}
      <Handle type="source" position={Position.Bottom} id="a" className="w-2 h-2 bg-[#abcd62]" />
    </div>
  )
}

export default memo(StartNode)

