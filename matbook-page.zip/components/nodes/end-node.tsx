import { memo } from "react"
import { Handle, Position } from "reactflow"

// End node component for workflow
function EndNode({ data }) {
  return (
    <div className="px-4 py-2 shadow-md rounded-md bg-[#ee3425] text-white">
      <div className="font-bold">{data.label}</div>
      {/* Only target handle (input) for end node */}
      <Handle type="target" position={Position.Top} id="a" className="w-2 h-2 bg-[#ee3425]" />
    </div>
  )
}

export default memo(EndNode)

