"use client"

import { useState, useEffect, useRef } from "react"
import { ChevronDown, Plus, Settings } from "lucide-react"
import { useWorkspaces } from "@/lib/workspace-context"
import { useRouter } from "next/navigation"

export default function WorkspaceSelector() {
  const { workspaces, currentWorkspace, setCurrentWorkspace } = useWorkspaces()
  const [isOpen, setIsOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const dropdownRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  // Filter workspaces based on search query
  const filteredWorkspaces = workspaces.filter((workspace) =>
    workspace.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Handle workspace selection
  const handleSelectWorkspace = (id: string) => {
    setCurrentWorkspace(id)
    setIsOpen(false)
  }

  // Handle create workspace
  const handleCreateWorkspace = () => {
    router.push("/workspaces/create")
    setIsOpen(false)
  }

  // Handle manage workspaces
  const handleManageWorkspaces = () => {
    router.push("/workspaces")
    setIsOpen(false)
  }

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Current workspace button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-md hover:bg-gray-100 text-sm font-medium"
      >
        <div className="w-6 h-6 rounded-md bg-blue-500 flex items-center justify-center text-white font-bold">
          {currentWorkspace ? currentWorkspace.name.charAt(0).toUpperCase() : "W"}
        </div>
        <span className="max-w-[150px] truncate">{currentWorkspace ? currentWorkspace.name : "Select Workspace"}</span>
        <ChevronDown className="h-4 w-4" />
      </button>

      {/* Dropdown */}
      {isOpen && (
        <div className="absolute left-0 mt-1 w-64 bg-white rounded-md shadow-lg z-50 border border-gray-200">
          {/* Search input */}
          <div className="p-2 border-b border-gray-200">
            <input
              type="text"
              placeholder="Search workspaces..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
            />
          </div>

          {/* Workspace list */}
          <div className="max-h-60 overflow-y-auto">
            {filteredWorkspaces.length > 0 ? (
              filteredWorkspaces.map((workspace) => (
                <button
                  key={workspace.id}
                  onClick={() => handleSelectWorkspace(workspace.id)}
                  className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 hover:bg-gray-100 ${
                    currentWorkspace && currentWorkspace.id === workspace.id ? "bg-gray-50" : ""
                  }`}
                >
                  <div className="w-6 h-6 rounded-md bg-blue-500 flex items-center justify-center text-white font-bold">
                    {workspace.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="truncate">{workspace.name}</span>
                </button>
              ))
            ) : (
              <div className="px-3 py-2 text-sm text-gray-500">No workspaces found</div>
            )}
          </div>

          {/* Actions */}
          <div className="border-t border-gray-200 p-2">
            <button
              onClick={handleCreateWorkspace}
              className="w-full text-left px-3 py-2 text-sm flex items-center gap-2 hover:bg-gray-100 rounded"
            >
              <Plus className="h-4 w-4" />
              <span>Create Workspace</span>
            </button>
            <button
              onClick={handleManageWorkspaces}
              className="w-full text-left px-3 py-2 text-sm flex items-center gap-2 hover:bg-gray-100 rounded"
            >
              <Settings className="h-4 w-4" />
              <span>Manage Workspaces</span>
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

