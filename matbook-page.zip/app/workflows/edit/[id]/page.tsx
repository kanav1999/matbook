"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Save, Plus, Trash2 } from "lucide-react"
import Header from "@/components/header"
import { useWorkflows } from "@/lib/workflow-context"
import SimpleWorkflowEditor from "@/components/simple-workflow-editor"
import apiService from "@/lib/api-service"

export default function EditWorkflowPage() {
  // Router and params
  const router = useRouter()
  const params = useParams()
  const workflowId = params.id

  // Workflow context
  const { getWorkflow, updateWorkflow } = useWorkflows()

  // Form state
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)

  // Workflow state
  const [nodes, setNodes] = useState([])
  const [connections, setConnections] = useState([])
  const [selectedNode, setSelectedNode] = useState(null)

  // Load workflow data on mount
  useEffect(() => {
    const loadWorkflow = async () => {
      try {
        const workflow = await getWorkflow(workflowId)
        if (workflow) {
          setName(workflow.name)
          setDescription(workflow.description || "")

          // Convert nodes to simplified format
          const simplifiedNodes = workflow.nodes.map((node) => ({
            id: node.id,
            type: node.type,
            label: node.data.label,
            x: node.position.x,
            y: node.position.y,
            ...(node.type === "api"
              ? {
                  url: node.data.url,
                  method: node.data.method,
                  body: node.data.body || "",
                }
              : {}),
            ...(node.type === "email"
              ? {
                  to: node.data.to,
                  subject: node.data.subject,
                  body: node.data.body,
                }
              : {}),
          }))

          // Convert edges to connections
          const simplifiedConnections = workflow.edges.map((edge) => ({
            source: edge.source,
            target: edge.target,
          }))

          setNodes(simplifiedNodes)
          setConnections(simplifiedConnections)
        }
      } catch (error) {
        console.error("Error loading workflow:", error)
        alert("Failed to load workflow. Please try again.")
      } finally {
        setIsLoading(false)
      }
    }

    loadWorkflow()
  }, [workflowId, getWorkflow])

  // Save the workflow
  const handleSave = async () => {
    if (!name) {
      alert("Please enter a workflow name")
      return
    }

    setIsSaving(true)

    try {
      // Convert to format expected by workflow context
      const formattedNodes = nodes.map((node) => ({
        id: node.id,
        type: node.type,
        position: { x: node.x, y: node.y },
        data: {
          label: node.label,
          ...(node.type === "api"
            ? {
                url: node.url || "https://beeceptor.com/console/sample-api-for-testing/users",
                method: node.method || "GET",
                body: node.body || "",
              }
            : {}),
          ...(node.type === "email"
            ? {
                to: node.to || "",
                subject: node.subject || "",
                body: node.body || "",
              }
            : {}),
        },
      }))

      const formattedEdges = connections.map((conn, index) => ({
        id: `e${index}`,
        source: conn.source,
        target: conn.target,
        animated: true,
      }))

      await updateWorkflow(workflowId, {
        name,
        description,
        nodes: formattedNodes,
        edges: formattedEdges,
      })

      router.push("/workflows")
    } catch (error) {
      console.error("Error saving workflow:", error)
      alert("Failed to save workflow. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  // Add a new node to the workflow
  const handleAddNode = (type) => {
    const newNode = {
      id: `${type}-${Date.now()}`,
      type,
      label: type.charAt(0).toUpperCase() + type.slice(1),
      x: 250,
      y: 200,
      ...(type === "api"
        ? {
            url: "https://beeceptor.com/console/sample-api-for-testing/users",
            method: "GET",
            body: "",
          }
        : {}),
      ...(type === "email"
        ? {
            to: "",
            subject: "",
            body: "",
          }
        : {}),
    }

    setNodes([...nodes, newNode])
  }

  // Delete selected node
  const handleDeleteNode = () => {
    if (!selectedNode) return

    // Don't allow deleting start or end nodes
    if (selectedNode.type === "start" || selectedNode.type === "end") {
      alert("Cannot delete start or end nodes")
      return
    }

    // Remove node
    setNodes(nodes.filter((node) => node.id !== selectedNode.id))

    // Remove connections to/from this node
    setConnections(connections.filter((conn) => conn.source !== selectedNode.id && conn.target !== selectedNode.id))

    setSelectedNode(null)
  }

  // Update node properties
  const updateNodeData = (id, data) => {
    setNodes(nodes.map((node) => (node.id === id ? { ...node, ...data } : node)))
  }

  // Test API call
  const testApiCall = async (url, method, body) => {
    try {
      const result = await apiService.executeApiCall(url, method, body ? JSON.parse(body) : undefined)
      alert(`API call successful! Response: ${JSON.stringify(result)}`)
      return result
    } catch (error) {
      console.error("API call failed:", error)
      alert(`API call failed: ${error.message}`)
      return null
    }
  }

  // Show loading indicator while fetching workflow data
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#ee3425]"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#fdfbf6]">
      <Header />

      <main className="container mx-auto px-4 py-4 sm:py-6">
        {/* Page header with title and save button */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 sm:mb-6">
          <h1 className="text-xl sm:text-2xl font-bold">Edit Workflow</h1>
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="bg-[#ee3425] hover:bg-[#d62e20] text-white px-3 py-1.5 sm:px-4 sm:py-2 rounded flex items-center gap-1 sm:gap-2 text-sm sm:text-base disabled:opacity-70"
          >
            {isSaving ? (
              <>
                <svg
                  className="animate-spin h-4 w-4 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                <span>Saving...</span>
              </>
            ) : (
              <>
                <Save className="h-3 w-3 sm:h-4 sm:w-4" />
                Save Workflow
              </>
            )}
          </button>
        </div>

        {/* Workflow details and node type buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-4 sm:mb-6">
          <div className="md:col-span-2">
            <div className="space-y-3 sm:space-y-4">
              <div>
                <label htmlFor="name" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
                  Workflow Name
                </label>
                <input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter workflow name"
                  className="w-full p-2 border border-gray-300 rounded text-sm"
                />
              </div>

              <div>
                <label htmlFor="description" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter workflow description"
                  className="w-full p-2 border border-gray-300 rounded text-sm"
                  rows={3}
                />
              </div>
            </div>
          </div>

          {/* Node type buttons */}
          <div className="flex flex-wrap gap-2 items-start">
            <button
              onClick={() => handleAddNode("api")}
              className="px-2 py-1 sm:px-3 sm:py-1.5 border border-gray-300 rounded flex items-center gap-1 hover:bg-gray-50 text-xs sm:text-sm"
            >
              <Plus className="h-3 w-3 sm:h-4 sm:w-4" />
              API
            </button>
            <button
              onClick={() => handleAddNode("email")}
              className="px-2 py-1 sm:px-3 sm:py-1.5 border border-gray-300 rounded flex items-center gap-1 hover:bg-gray-50 text-xs sm:text-sm"
            >
              <Plus className="h-3 w-3 sm:h-4 sm:w-4" />
              Email
            </button>
            {selectedNode && selectedNode.type !== "start" && selectedNode.type !== "end" && (
              <button
                onClick={handleDeleteNode}
                className="px-2 py-1 sm:px-3 sm:py-1.5 border border-red-300 text-red-600 rounded flex items-center gap-1 hover:bg-red-50 text-xs sm:text-sm"
              >
                <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                Delete Node
              </button>
            )}
          </div>
        </div>

        {/* Workflow editor */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 sm:gap-6">
          <div className="md:col-span-3 bg-white rounded-md border h-[400px] sm:h-[600px] relative">
            <SimpleWorkflowEditor
              nodes={nodes}
              connections={connections}
              onNodesChange={setNodes}
              onConnectionsChange={setConnections}
              onSelectNode={setSelectedNode}
              selectedNode={selectedNode}
            />
          </div>

          {/* Node properties panel */}
          <div className="bg-white rounded-md border p-3 sm:p-4 h-[400px] sm:h-[600px] overflow-y-auto">
            {selectedNode ? (
              <NodePropertiesPanel
                node={selectedNode}
                updateNodeData={(data) => updateNodeData(selectedNode.id, data)}
                testApiCall={testApiCall}
              />
            ) : (
              <div className="text-center text-gray-500 py-8 text-xs sm:text-sm">
                Select a node to configure its properties
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

// Node properties panel component
function NodePropertiesPanel({ node, updateNodeData, testApiCall }) {
  // Handle input changes
  const handleChange = (key, value) => {
    updateNodeData({ [key]: value })
  }

  // Render different forms based on node type
  if (node.type === "start" || node.type === "end") {
    return (
      <div>
        <h3 className="font-medium mb-4 text-sm sm:text-base">{node.label} Node</h3>
        <p className="text-xs sm:text-sm text-gray-500">This is a {node.type} node. No configuration needed.</p>
      </div>
    )
  }

  if (node.type === "api") {
    return (
      <div className="space-y-3 sm:space-y-4">
        <h3 className="font-medium text-sm sm:text-base">API Node Configuration</h3>

        <div>
          <label htmlFor="label" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            Label
          </label>
          <input
            id="label"
            value={node.label || ""}
            onChange={(e) => handleChange("label", e.target.value)}
            className="w-full p-2 border border-gray-300 rounded text-xs sm:text-sm"
          />
        </div>

        <div>
          <label htmlFor="url" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            URL
          </label>
          <input
            id="url"
            value={node.url || ""}
            onChange={(e) => handleChange("url", e.target.value)}
            placeholder="https://api.example.com"
            className="w-full p-2 border border-gray-300 rounded text-xs sm:text-sm"
          />
        </div>

        <div>
          <label htmlFor="method" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            Method
          </label>
          <select
            id="method"
            value={node.method || "GET"}
            onChange={(e) => handleChange("method", e.target.value)}
            className="w-full p-2 border border-gray-300 rounded text-xs sm:text-sm"
          >
            <option value="GET">GET</option>
            <option value="POST">POST</option>
            <option value="PUT">PUT</option>
            <option value="DELETE">DELETE</option>
          </select>
        </div>

        <div>
          <label htmlFor="body" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            Request Body (JSON)
          </label>
          <textarea
            id="body"
            value={node.body || ""}
            onChange={(e) => handleChange("body", e.target.value)}
            placeholder="{}"
            className="w-full p-2 border border-gray-300 rounded text-xs sm:text-sm"
            rows={4}
          />
        </div>

        <button
          onClick={() => testApiCall(node.url, node.method, node.body)}
          className="px-3 py-1.5 bg-blue-500 hover:bg-blue-600 text-white rounded text-xs sm:text-sm"
        >
          Test API Call
        </button>
      </div>
    )
  }

  if (node.type === "email") {
    return (
      <div className="space-y-3 sm:space-y-4">
        <h3 className="font-medium text-sm sm:text-base">Email Node Configuration</h3>

        <div>
          <label htmlFor="label" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            Label
          </label>
          <input
            id="label"
            value={node.label || ""}
            onChange={(e) => handleChange("label", e.target.value)}
            className="w-full p-2 border border-gray-300 rounded text-xs sm:text-sm"
          />
        </div>

        <div>
          <label htmlFor="to" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            To
          </label>
          <input
            id="to"
            value={node.to || ""}
            onChange={(e) => handleChange("to", e.target.value)}
            placeholder="recipient@example.com"
            className="w-full p-2 border border-gray-300 rounded text-xs sm:text-sm"
          />
        </div>

        <div>
          <label htmlFor="subject" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            Subject
          </label>
          <input
            id="subject"
            value={node.subject || ""}
            onChange={(e) => handleChange("subject", e.target.value)}
            placeholder="Email subject"
            className="w-full p-2 border border-gray-300 rounded text-xs sm:text-sm"
          />
        </div>

        <div>
          <label htmlFor="body" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            Email Body
          </label>
          <textarea
            id="body"
            value={node.body || ""}
            onChange={(e) => handleChange("body", e.target.value)}
            placeholder="Email content..."
            className="w-full p-2 border border-gray-300 rounded text-xs sm:text-sm"
            rows={4}
          />
        </div>
      </div>
    )
  }

  return <div className="text-center text-gray-500 py-8 text-xs sm:text-sm">Unknown node type: {node.type}</div>
}

