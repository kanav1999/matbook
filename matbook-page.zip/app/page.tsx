"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"

export default function Home() {
  // Router and auth context
  const router = useRouter()
  const { user } = useAuth()

  // Redirect based on authentication status
  useEffect(() => {
    if (user) {
      router.push("/workflows")
    } else {
      router.push("/login")
    }
  }, [user, router])

  return null
}

