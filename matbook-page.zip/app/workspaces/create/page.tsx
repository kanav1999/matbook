"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Save } from "lucide-react"
import Header from "@/components/header"
import { useWorkspaces } from "@/lib/workspace-context"

export default function CreateWorkspacePage() {
  // Router and workspace context
  const router = useRouter()
  const { createWorkspace } = useWorkspaces()

  // Form state
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  // Save the workspace
  const handleSave = async () => {
    if (!name) {
      alert("Please enter a workspace name")
      return
    }

    setIsLoading(true)

    try {
      await createWorkspace({
        name,
        description,
      })

      router.push("/workspaces")
    } catch (error) {
      console.error("Error creating workspace:", error)
      alert("Failed to create workspace. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#fdfbf6]">
      <Header />

      <main className="container mx-auto px-4 py-4 sm:py-6">
        {/* Page header with title and save button */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 sm:mb-6">
          <h1 className="text-xl sm:text-2xl font-bold">Create Workspace</h1>
          <button
            onClick={handleSave}
            disabled={isLoading}
            className="bg-[#ee3425] hover:bg-[#d62e20] text-white px-3 py-1.5 sm:px-4 sm:py-2 rounded flex items-center gap-1 sm:gap-2 text-sm sm:text-base disabled:opacity-70"
          >
            {isLoading ? (
              <>
                <svg
                  className="animate-spin h-4 w-4 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                <span>Saving...</span>
              </>
            ) : (
              <>
                <Save className="h-3 w-3 sm:h-4 sm:w-4" />
                Save Workspace
              </>
            )}
          </button>
        </div>

        {/* Workspace form */}
        <div className="bg-white rounded-md border p-4 sm:p-6">
          <div className="space-y-4 max-w-2xl">
            <div>
              <label htmlFor="name" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
                Workspace Name
              </label>
              <input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter workspace name"
                className="w-full p-2 border border-gray-300 rounded text-sm"
              />
            </div>

            <div>
              <label htmlFor="description" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter workspace description"
                className="w-full p-2 border border-gray-300 rounded text-sm"
                rows={4}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

