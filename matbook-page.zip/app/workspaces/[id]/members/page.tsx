"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { UserPlus, X, ChevronLeft, Mail, Shield, User, UserX } from "lucide-react"
import Header from "@/components/header"
import { useWorkspaces } from "@/lib/workspace-context"

export default function WorkspaceMembersPage() {
  // Router and params
  const router = useRouter()
  const params = useParams()
  const workspaceId = params.id

  // Workspace context
  const { getWorkspace, inviteMember, removeMember, updateMemberRole } = useWorkspaces()

  // State
  const [workspace, setWorkspace] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [showInviteModal, setShowInviteModal] = useState(false)
  const [inviteEmail, setInviteEmail] = useState("")
  const [inviteRole, setInviteRole] = useState<"admin" | "member" | "viewer">("member")
  const [isInviting, setIsInviting] = useState(false)
  const [showRemoveModal, setShowRemoveModal] = useState(false)
  const [selectedMember, setSelectedMember] = useState<any>(null)

  // Load workspace data on mount
  useEffect(() => {
    const loadWorkspace = async () => {
      try {
        const workspaceData = await getWorkspace(workspaceId)
        if (workspaceData) {
          setWorkspace(workspaceData)
        } else {
          router.push("/workspaces")
        }
      } catch (error) {
        console.error("Error loading workspace:", error)
        alert("Failed to load workspace. Please try again.")
        router.push("/workspaces")
      } finally {
        setIsLoading(false)
      }
    }

    loadWorkspace()
  }, [workspaceId, getWorkspace, router])

  // Handle invite member
  const handleInvite = async () => {
    if (!inviteEmail) {
      alert("Please enter an email address")
      return
    }

    setIsInviting(true)

    try {
      await inviteMember(workspaceId, {
        email: inviteEmail,
        role: inviteRole,
      })

      // Refresh workspace data
      const workspaceData = await getWorkspace(workspaceId)
      if (workspaceData) {
        setWorkspace(workspaceData)
      }

      setInviteEmail("")
      setInviteRole("member")
      setShowInviteModal(false)
    } catch (error) {
      console.error("Error inviting member:", error)
      alert("Failed to invite member. Please try again.")
    } finally {
      setIsInviting(false)
    }
  }

  // Handle remove member
  const handleRemoveMember = async () => {
    if (!selectedMember) return

    try {
      await removeMember(workspaceId, selectedMember.userId)

      // Refresh workspace data
      const workspaceData = await getWorkspace(workspaceId)
      if (workspaceData) {
        setWorkspace(workspaceData)
      }

      setSelectedMember(null)
      setShowRemoveModal(false)
    } catch (error) {
      console.error("Error removing member:", error)
      alert("Failed to remove member. Please try again.")
    }
  }

  // Handle update member role
  const handleUpdateRole = async (userId: string, role: "admin" | "member" | "viewer") => {
    try {
      await updateMemberRole(workspaceId, userId, role)

      // Refresh workspace data
      const workspaceData = await getWorkspace(workspaceId)
      if (workspaceData) {
        setWorkspace(workspaceData)
      }
    } catch (error) {
      console.error("Error updating member role:", error)
      alert("Failed to update member role. Please try again.")
    }
  }

  // Show loading indicator while fetching workspace data
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#ee3425]"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#fdfbf6]">
      <Header />

      <main className="container mx-auto px-4 py-4 sm:py-6">
        {/* Page header with title and back button */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 sm:mb-6">
          <div>
            <button
              onClick={() => router.push("/workspaces")}
              className="flex items-center text-gray-600 hover:text-gray-900 mb-2"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              <span className="text-sm">Back to Workspaces</span>
            </button>
            <h1 className="text-xl sm:text-2xl font-bold">{workspace.name} - Members</h1>
          </div>
          <button
            onClick={() => setShowInviteModal(true)}
            className="bg-[#ee3425] hover:bg-[#d62e20] text-white px-3 py-1.5 sm:px-4 sm:py-2 rounded flex items-center gap-1 sm:gap-2 text-sm sm:text-base"
          >
            <UserPlus className="h-3 w-3 sm:h-4 sm:w-4" />
            Invite Member
          </button>
        </div>

        {/* Members list */}
        <div className="bg-white rounded-md border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 text-left">
                <tr>
                  <th className="px-3 sm:px-6 py-2 sm:py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-3 sm:px-6 py-2 sm:py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Role
                  </th>
                  <th className="hidden sm:table-cell px-3 sm:px-6 py-2 sm:py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Joined On
                  </th>
                  <th className="px-3 sm:px-6 py-2 sm:py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {workspace.members.map((member) => (
                  <tr key={member.id} className="hover:bg-gray-50">
                    <td className="px-3 sm:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm">
                      <div className="flex items-center">
                        <Mail className="h-3 w-3 sm:h-4 sm:w-4 text-gray-400 mr-2" />
                        {member.email}
                      </div>
                    </td>
                    <td className="px-3 sm:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm">
                      <div className="flex items-center">
                        {member.role === "owner" ? (
                          <div className="flex items-center text-yellow-600">
                            <Shield className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
                            Owner
                          </div>
                        ) : member.role === "admin" ? (
                          <div className="flex items-center text-blue-600">
                            <Shield className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
                            Admin
                          </div>
                        ) : member.role === "member" ? (
                          <div className="flex items-center text-green-600">
                            <User className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
                            Member
                          </div>
                        ) : (
                          <div className="flex items-center text-gray-600">
                            <User className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
                            Viewer
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="hidden sm:table-cell px-3 sm:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">
                      {new Date(member.joinedAt).toLocaleDateString()}
                    </td>
                    <td className="px-3 sm:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm">
                      {member.role !== "owner" && (
                        <div className="flex items-center space-x-2">
                          <select
                            value={member.role}
                            onChange={(e) => handleUpdateRole(member.userId, e.target.value as any)}
                            className="text-xs sm:text-sm border border-gray-300 rounded py-1 px-2"
                          >
                            <option value="admin">Admin</option>
                            <option value="member">Member</option>
                            <option value="viewer">Viewer</option>
                          </select>
                          <button
                            onClick={() => {
                              setSelectedMember(member)
                              setShowRemoveModal(true)
                            }}
                            className="text-red-600 hover:text-red-800"
                          >
                            <UserX className="h-3 w-3 sm:h-4 sm:w-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Invite member modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-lg max-w-md w-full p-4 sm:p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-base sm:text-lg font-medium">Invite Member</h3>
              <button onClick={() => setShowInviteModal(false)} className="text-gray-400 hover:text-gray-500">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="Enter email address"
                  className="w-full p-2 border border-gray-300 rounded text-sm"
                />
              </div>
              <div>
                <label htmlFor="role" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
                  Role
                </label>
                <select
                  id="role"
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as any)}
                  className="w-full p-2 border border-gray-300 rounded text-sm"
                >
                  <option value="admin">Admin</option>
                  <option value="member">Member</option>
                  <option value="viewer">Viewer</option>
                </select>
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <button
                  onClick={() => setShowInviteModal(false)}
                  disabled={isInviting}
                  className="px-3 py-1.5 sm:px-4 sm:py-2 border border-gray-300 rounded text-xs sm:text-sm hover:bg-gray-50 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleInvite}
                  disabled={isInviting}
                  className="px-3 py-1.5 sm:px-4 sm:py-2 bg-[#ee3425] hover:bg-[#d62e20] text-white rounded text-xs sm:text-sm disabled:opacity-70 flex items-center"
                >
                  {isInviting ? (
                    <>
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Inviting...
                    </>
                  ) : (
                    "Invite"
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Remove member modal */}
      {showRemoveModal && selectedMember && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-lg max-w-md w-full p-4 sm:p-6">
            <h3 className="text-base sm:text-lg font-medium mb-2">Remove Member</h3>
            <p className="text-xs sm:text-sm text-gray-500 mb-4">
              Are you sure you want to remove {selectedMember.email} from this workspace?
            </p>
            <div className="flex justify-end space-x-2">
              <button
                onClick={() => {
                  setSelectedMember(null)
                  setShowRemoveModal(false)
                }}
                className="px-3 py-1.5 sm:px-4 sm:py-2 border border-gray-300 rounded text-xs sm:text-sm hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleRemoveMember}
                className="px-3 py-1.5 sm:px-4 sm:py-2 bg-red-600 hover:bg-red-700 text-white rounded text-xs sm:text-sm"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

