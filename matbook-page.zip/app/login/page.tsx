"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"

export default function LoginPage() {
  // State for form inputs
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(true)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  // Get router and auth context
  const router = useRouter()
  const { login } = useAuth()

  // Handle login form submission
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Validate inputs
    if (!email || !password) {
      setError("Please enter both email and password")
      setIsLoading(false)
      return
    }

    try {
      // Call login function from auth context
      await login(email, password)
      router.push("/workflows") // Redirect to workflows page on success
    } catch (err) {
      setError("Invalid email or password")
      setIsLoading(false)
    }
  }

  // Handle social login
  const handleSocialLogin = (provider: string) => {
    // In a real app, this would integrate with OAuth providers
    alert(`Login with ${provider} - This would integrate with the ${provider} OAuth in a production app`)
  }

  return (
    <div className="flex min-h-screen w-full flex-col md:flex-row">
      {/* Left side - Background with logo and text */}
      <div className="hidden md:flex md:w-1/2 flex-col p-6 lg:p-12 bg-gradient-to-br from-[#2c3e50] to-[#849e4c] text-white relative overflow-hidden">
        {/* Logo and content */}
        <div className="z-10 relative">
          {/* HighBridge Logo */}
          <div className="flex items-center gap-2 mb-8 lg:mb-16">
            <div className="bg-white rounded-full p-2 w-10 h-10 lg:w-12 lg:h-12 flex items-center justify-center">
              <div className="w-6 h-6 lg:w-8 lg:h-8 bg-green-600 rounded-full"></div>
            </div>
            <span className="font-semibold text-xl lg:text-2xl">HighBridge</span>
          </div>

          {/* Tagline and description */}
          <div className="mt-12 lg:mt-24">
            <h1 className="text-2xl lg:text-3xl font-bold mb-3">Building the Future...</h1>
            <div className="border border-[#e91e63] p-3 lg:p-4 max-w-xs bg-black/10">
              <p className="text-xs lg:text-sm opacity-90">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                dolore magna aliqua.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Login form */}
      <div className="w-full md:w-1/2 flex items-center justify-center bg-[#ffffff] p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-md">
          {/* Login form header */}
          <div className="mb-6 lg:mb-8">
            <p className="text-xs sm:text-sm text-gray-600 mb-1">WELCOME BACK!</p>
            <h2 className="text-xl sm:text-2xl font-bold">Log In to your Account</h2>
          </div>

          {/* Login form */}
          <form onSubmit={handleLogin} className="space-y-4 lg:space-y-6">
            {/* Error message */}
            {error && <div className="p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded">{error}</div>}

            {/* Email field */}
            <div className="space-y-1 sm:space-y-2">
              <label htmlFor="email" className="text-xs sm:text-sm text-gray-600">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Type here..."
                className="w-full p-2 sm:p-3 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#ee3425]"
              />
            </div>

            {/* Password field */}
            <div className="space-y-1 sm:space-y-2">
              <label htmlFor="password" className="text-xs sm:text-sm text-gray-600">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Type here..."
                className="w-full p-2 sm:p-3 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#ee3425]"
              />
            </div>

            {/* Remember me and forgot password */}
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <div
                  className={`w-4 h-4 sm:w-5 sm:h-5 flex items-center justify-center rounded cursor-pointer ${rememberMe ? "bg-[#ee3425]" : "border border-gray-300"}`}
                  onClick={() => setRememberMe(!rememberMe)}
                >
                  {rememberMe && (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-2 w-2 sm:h-3 sm:w-3 text-white"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  )}
                </div>
                <label
                  htmlFor="remember"
                  className="text-xs sm:text-sm text-gray-600 cursor-pointer"
                  onClick={() => setRememberMe(!rememberMe)}
                >
                  Remember me
                </label>
              </div>

              <a href="#" className="text-xs sm:text-sm text-gray-600 hover:underline">
                Forgot Password?
              </a>
            </div>

            {/* Login button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2 sm:py-3 bg-[#ee3425] hover:bg-[#d62e20] text-white font-medium rounded transition-colors text-sm sm:text-base disabled:opacity-70"
            >
              {isLoading ? "Logging in..." : "Log In"}
            </button>

            {/* Or divider */}
            <div className="relative flex items-center justify-center">
              <div className="border-t border-gray-300 w-full"></div>
              <span className="bg-white px-2 sm:px-3 text-xs sm:text-sm text-gray-500 absolute">Or</span>
            </div>

            {/* Social login options */}
            <div className="space-y-2 sm:space-y-3">
              {/* Google login */}
              <button
                type="button"
                onClick={() => handleSocialLogin("Google")}
                className="w-full py-2 sm:py-2.5 border border-gray-300 rounded flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors text-xs sm:text-sm"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#4285F4">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    fill="#34A853"
                  />
                  <path
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    fill="#FBBC05"
                  />
                  <path
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    fill="#EA4335"
                  />
                </svg>
                <span className="text-gray-600">Log in with Google</span>
              </button>

              {/* Facebook login */}
              <button
                type="button"
                onClick={() => handleSocialLogin("Facebook")}
                className="w-full py-2 sm:py-2.5 border border-gray-300 rounded flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors text-xs sm:text-sm"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#1877F2">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
                <span className="text-gray-600">Log in with Facebook</span>
              </button>

              {/* Apple login */}
              <button
                type="button"
                onClick={() => handleSocialLogin("Apple")}
                className="w-full py-2 sm:py-2.5 border border-gray-300 rounded flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors text-xs sm:text-sm"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="black">
                  <path d="M16.462 16.965c-.393.872-.941 1.68-1.641 2.414-.47.5-.995.976-1.579 1.414-.704.527-1.283.789-1.732.789-.445 0-1.023-.18-1.732-.539-.711-.359-1.359-.539-1.944-.539-.621 0-1.265.18-1.933.539-.669.359-1.209.549-1.617.57-.625.039-1.249-.189-1.873-.688-.625-.5-1.173-.996-1.641-1.488-.937-1.027-1.683-2.227-2.242-3.602-.6-1.469-.9-2.895-.9-4.277 0-1.57.379-2.926 1.138-4.066.599-.91 1.393-1.629 2.385-2.156.991-.527 2.062-.8 3.213-.82.63 0 1.456.195 2.482.586 1.025.391 1.686.586 1.979.586.217 0 .952-.23 2.203-.688 1.183-.43 2.184-.607 3.004-.539 2.217.18 3.883 1.059 4.994 2.637-1.983 1.201-2.965 2.875-2.944 5.027.019 1.676.625 3.07 1.819 4.184.542.527 1.151.937 1.823 1.227-.146.449-.302.879-.464 1.289zm-4.921-19.965c0 1.312-.479 2.535-1.438 3.668-.957 1.133-2.115 1.789-3.473 1.684-.016-.129-.025-.266-.025-.41 0-1.312.525-2.535 1.575-3.668.525-.566 1.191-1.035 2-1.406.807-.371 1.57-.578 2.286-.617.021.129.033.266.033.41.001.001.001.129.042.339z" />
                </svg>
                <span className="text-gray-600">Log in with Apple</span>
              </button>
            </div>

            {/* Sign up link */}
            <div className="text-center">
              <p className="text-xs sm:text-sm text-gray-600">
                New User? <span className="text-[#e91e63] font-bold cursor-pointer">SIGN UP HERE</span>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

